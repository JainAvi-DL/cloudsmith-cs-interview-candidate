"""Example package for Cloudsmith assessment."""

__version__ = "0.1.0" 